package com.example.unicon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class weight extends AppCompatActivity {

    String[] weight = {"Kilogram", "Gram", "Pound", "Ounce"};
    TextView tv1_wt;
    TextView tv2_wt;
    EditText et1_wt;
    EditText et2_wt;
    String dtostr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);
        tv1_wt = findViewById(R.id.tv1_wt);
        tv2_wt = findViewById(R.id.tv2_wt);
        et1_wt = findViewById(R.id.et1_wt);
        et2_wt = findViewById(R.id.et2_wt);

        setTitle("Convert Weight");

        Spinner spin = (Spinner) findViewById(R.id.spn_wt);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {



                switch(i){
                    case 0:
                        tv1_wt.setText("Kilogram");
                        String tvsec =  tv2_wt.getText().toString();
                        String s = et2_wt.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double kg = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilogram")) {
                                dtostr = kg.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Gram")) {
                                Double gram = kg / 1000;
                                dtostr = gram.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Pound")) {
                                Double pound = kg * 0.45359237;
                                dtostr = pound.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Ounce")) {
                                Double ounce = kg * 0.028349523;
                                dtostr = ounce.toString();
                                et1_wt.setText(dtostr);
                            }

                        }
                        break;
                    case 1:
                        tv1_wt.setText("Gram");
                        tvsec =  tv2_wt.getText().toString();
                        s = et2_wt.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double gm = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilogram")) {
                                Double gram = gm*1000;
                                dtostr = gram.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Gram")) {
                                dtostr = gm.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Pound")) {
                                Double pound = gm * 453.659237;
                                dtostr = pound.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Ounce")) {
                                Double ounce = gm * 28.349523;
                                dtostr = ounce.toString();
                                et1_wt.setText(dtostr);
                            }

                        }
                        break;
                    case 2:
                        tv1_wt.setText("Pound");
                        tvsec =  tv2_wt.getText().toString();
                        s = et2_wt.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double pd = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilogram")) {
                                Double kilo = pd * 2.20462;
                                dtostr = kilo.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Gram")) {
                                Double gram = pd * 453.6;
                                dtostr = gram.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Pound")) {
                                 dtostr = pd.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Ounce")) {
                                Double ounce = pd * 16;
                                dtostr = ounce.toString();
                                et1_wt.setText(dtostr);
                            }

                        }
                        break;
                    case 3:
                        tv1_wt.setText("Ounce");
                        tvsec =  tv2_wt.getText().toString();
                        s = et2_wt.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double oun = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilogram")) {
                                Double kilo = oun * 35.274;
                                dtostr = kilo.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Gram")) {
                                Double gram = oun *28.35;
                                dtostr = gram.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Pound")) {
                                Double pound = oun * 16;
                                dtostr = pound.toString();
                                et1_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Ounce")) {
                                dtostr = oun.toString();
                                et1_wt.setText(dtostr);
                            }

                        }
                        break;
                }



            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, weight);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);


        Spinner spin2 = (Spinner) findViewById(R.id.spn_wt2);
        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String dtostr;
                switch(i){
                    case 0:
                        tv2_wt.setText("Kilogram");
                        String tvsec =  tv1_wt.getText().toString();
                        String s = et1_wt.getText().toString();
                        if(!s.equals("") && s!=null ) {
                            Double kg = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilogram")) {
                                dtostr = kg.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Gram")) {
                                Double gram = kg / 1000;
                                dtostr = gram.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Pound")) {
                                Double pound = kg * 0.45359237;
                                dtostr = pound.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Ounce")) {
                                Double ounce = kg * 0.028349523;
                                dtostr = ounce.toString();
                                et2_wt.setText(dtostr);
                            }

                        }
                        break;
                    case 1:
                        tv2_wt.setText("Gram");
                        tvsec =  tv1_wt.getText().toString();
                        s = et1_wt.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double gm = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilogram")) {
                                Double gram = gm*1000;
                                dtostr = gram.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Gram")) {
                                dtostr = gm.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Pound")) {
                                Double pound = gm * 453.659237;
                                dtostr = pound.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Ounce")) {
                                Double ounce = gm * 28.349523;
                                dtostr = ounce.toString();
                                et2_wt.setText(dtostr);
                            }

                        }
                        break;
                    case 2:
                        tv2_wt.setText("Pound");
                        tvsec =  tv1_wt.getText().toString();
                        s = et1_wt.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double pd = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilogram")) {
                                Double kilo = pd * 2.20462;
                                dtostr = kilo.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Gram")) {
                                Double gram = pd * 453.6;
                                dtostr = gram.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Pound")) {
                                dtostr = pd.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Ounce")) {
                                Double ounce = pd * 16;
                                dtostr = ounce.toString();
                                et2_wt.setText(dtostr);
                            }

                        }
                        break;
                    case 3:
                        tv2_wt.setText("Ounce");
                        tvsec =  tv1_wt.getText().toString();
                        s = et1_wt.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double oun = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilogram")) {
                                Double kilo = oun * 35.274;
                                dtostr = kilo.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Gram")) {
                                Double gram = oun *28.35;
                                dtostr = gram.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Pound")) {
                                Double pound = oun * 16;
                                dtostr = pound.toString();
                                et2_wt.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Ounce")) {
                                dtostr = oun.toString();
                                et2_wt.setText(dtostr);
                            }

                        }
                        break;
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter bb = new ArrayAdapter (this,android.R.layout.simple_spinner_item, weight);
        bb.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin2.setAdapter(bb);



    }


}









