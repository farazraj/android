package com.example.unicon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class currency extends AppCompatActivity {

    String[] currency = {"Rupees", "Kuwait Dinar", "Dirham", "US Dollar"};
    TextView tv1_cr;
    TextView tv2_cr;
    EditText et1_cr;
    EditText et2_cr;
    String dtostr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency);

        tv1_cr = findViewById(R.id.tv1_cr);
        tv2_cr = findViewById(R.id.tv2_cr);
        et1_cr = findViewById(R.id.et1_cr);
        et2_cr = findViewById(R.id.et2_cr);


        setTitle("Convert Currency");

        Spinner spin = (Spinner) findViewById(R.id.spn_cr);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {



                switch(i){
                    case 0:
                        tv1_cr.setText("Rupees");
                        String tvsec =  tv2_cr.getText().toString();
                        String s = et2_cr.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double rs = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Rupees")) {
                                dtostr = rs.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Kuwait Dinar")) {
                                Double kwd = rs * 265.57;
                                dtostr = kwd.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Dirham")) {
                                Double dhs = rs * 22.248968 ;
                                dtostr = dhs.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("US Dollar")) {
                                Double usd = rs * 81.67 ;
                                dtostr = usd.toString();
                                et1_cr.setText(dtostr);
                            }

                        }

                        break;
                    case 1:
                        tv1_cr.setText("Kuwait Dinar");
                        tvsec =  tv2_cr.getText().toString();
                        s = et2_cr.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double kwd = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Rupees")) {
                                Double rs = kwd * 0.0038;
                                dtostr = kwd.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Kuwait Dinar")) {
                                dtostr = kwd.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Dirham")) {
                                Double dhs = kwd * 11.9417 ;
                                dtostr = dhs.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("US Dollar")) {
                                Double usd = kwd * 0.31 ;
                                dtostr = usd.toString();
                                et1_cr.setText(dtostr);
                            }

                        }
                        break;
                    case 2:
                        tv1_cr.setText("Dirham");
                        tvsec =  tv2_cr.getText().toString();
                        s = et2_cr.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double dhs = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Rupees")) {
                                Double rs = dhs * 0.045 ;
                                dtostr = rs.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Kuwait Dinar")) {
                                Double kwd = dhs * 11.94;
                                dtostr = kwd.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Dirham")) {
                                dtostr = dhs.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("US Dollar")) {
                                Double usd = dhs * 3.67 ;
                                dtostr = usd.toString();
                                et1_cr.setText(dtostr);
                            }

                        }
                        break;
                    case 3:
                        tv1_cr.setText("US Dollar");
                        tvsec =  tv2_cr.getText().toString();
                        s = et2_cr.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double usd = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Rupees")) {
                                Double rs = usd * 0.012  ;
                                dtostr = rs.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Kuwait Dinar")) {
                                Double kwd = usd * 3.25;
                                dtostr = kwd.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Dirham")) {
                                Double dhs = usd * 0.27 ;
                                dtostr = dhs.toString();
                                et1_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("US Dollar")) {
                                 dtostr = usd.toString();
                                et1_cr.setText(dtostr);
                            }

                        }
                        break;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, currency);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);


        Spinner spin2 = (Spinner) findViewById(R.id.spn_cr2);
        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {



                switch(i){
                    case 0:
                        tv2_cr.setText("Rupees");
                        String tvsec =  tv1_cr.getText().toString();
                        String s = et1_cr.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double rs = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Rupees")) {
                                dtostr = rs.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Kuwait Dinar")) {
                                Double kwd = rs * 265.57;
                                dtostr = kwd.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Dirham")) {
                                Double dhs = rs * 22.248968 ;
                                dtostr = dhs.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("US Dollar")) {
                                Double usd = rs * 81.67 ;
                                dtostr = usd.toString();
                                et2_cr.setText(dtostr);
                            }

                        }

                        break;
                    case 1:
                        tv2_cr.setText("Kuwait Dinar");
                        tvsec =  tv1_cr.getText().toString();
                        s = et1_cr.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double kwd = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Rupees")) {
                                Double rs = kwd * 0.0038;
                                dtostr = kwd.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Kuwait Dinar")) {
                                dtostr = kwd.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Dirham")) {
                                Double dhs = kwd * 11.9417 ;
                                dtostr = dhs.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("US Dollar")) {
                                Double usd = kwd * 0.31 ;
                                dtostr = usd.toString();
                                et2_cr.setText(dtostr);
                            }

                        }
                        break;
                    case 2:
                        tv2_cr.setText("Dirham");
                        tvsec =  tv1_cr.getText().toString();
                        s = et1_cr.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double dhs = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Rupees")) {
                                Double rs = dhs * 0.045 ;
                                dtostr = rs.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Kuwait Dinar")) {
                                Double kwd = dhs * 11.94;
                                dtostr = kwd.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Dirham")) {
                                dtostr = dhs.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("US Dollar")) {
                                Double usd = dhs * 3.67 ;
                                dtostr = usd.toString();
                                et2_cr.setText(dtostr);
                            }

                        }
                        break;
                    case 3:
                        tv2_cr.setText("US Dollar");
                        tvsec =  tv1_cr.getText().toString();
                        s = et1_cr.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double usd = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Rupees")) {
                                Double rs = usd * 0.012  ;
                                dtostr = rs.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Kuwait Dinar")) {
                                Double kwd = usd * 3.25;
                                dtostr = kwd.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Dirham")) {
                                Double dhs = usd * 0.27 ;
                                dtostr = dhs.toString();
                                et2_cr.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("US Dollar")) {
                                dtostr = usd.toString();
                                et2_cr.setText(dtostr);
                            }

                        }
                        break;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter bb = new ArrayAdapter (this,android.R.layout.simple_spinner_item, currency);
        bb.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin2.setAdapter(bb);



    }


}









