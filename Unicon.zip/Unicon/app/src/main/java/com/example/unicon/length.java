package com.example.unicon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class length extends AppCompatActivity {

    String[] length = {"Meter", "Centimeter", "Millimeter","Foot","Inch"};
    TextView tv1_len;
    TextView tv2_len;
    EditText et1_len;
    EditText et2_len;
    String dtostr;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);
        tv1_len = findViewById(R.id.tv1_len);
        tv2_len = findViewById(R.id.tv2_len);
        et2_len = findViewById(R.id.et2_len);
        et1_len = findViewById(R.id.et1_len);


        setTitle("Convert Length");

        Spinner spin = (Spinner) findViewById(R.id.spn_len);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {



                switch(i){
                    case 0:
                        tv1_len.setText("Meter");
                        String tvsec =  tv2_len.getText().toString();
                        String s = et2_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double mtr = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                dtostr = mtr.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                Double cm = mtr/100;
                                dtostr = cm.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                Double ft = mtr/3.281 ;
                                dtostr = ft.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                Double in = mtr/39.37;
                                dtostr = in.toString();
                                et1_len.setText(dtostr);
                            }

                        }

                        break;
                    case 1:
                        tv1_len.setText("Centimeter");
                        tvsec =  tv2_len.getText().toString();
                        s = et2_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double cm = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                Double mtr = cm*100;
                                dtostr = mtr.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                dtostr = cm.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                Double ft = cm*30.48;
                                dtostr = ft.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                Double in = cm*2.54;
                                dtostr = in.toString();
                                et1_len.setText(dtostr);
                            }

                        }

                        break;
                    case 2:
                        tv1_len.setText("Millimeter");
                        tvsec =  tv2_len.getText().toString();
                        s = et2_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double mm = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                Double mtr = mm*1000;
                                dtostr = mtr.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                Double cm = mm*100;
                                dtostr = cm.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                Double ft = mm*304.8;
                                dtostr = ft.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                Double in = mm*25.4;
                                dtostr = in.toString();
                                et1_len.setText(dtostr);
                            }

                        }

                        break;
                    case 3:
                        tv1_len.setText("Foot");
                        tvsec =  tv2_len.getText().toString();
                        s = et2_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double ft = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                Double mtr = ft*3.281;
                                dtostr = mtr.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                Double cm = ft/30.48;
                                dtostr = cm.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                dtostr = ft.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                Double in = ft/12;
                                dtostr = in.toString();
                                et1_len.setText(dtostr);
                            }

                        }

                        break;
                    case 4:
                        tv1_len.setText("Inch");
                        tvsec =  tv2_len.getText().toString();
                        s = et2_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double in = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                Double mtr = in* 39.37;
                                dtostr = mtr.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                Double cm = in/2.54;
                                dtostr = cm.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                Double ft = in*12;
                                dtostr = in.toString();
                                et1_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                dtostr = in.toString();
                                et1_len.setText(dtostr);
                            }

                        }

                        break;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, length);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);


        Spinner spin2 = (Spinner) findViewById(R.id.spn_len2);
        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                switch(i){
                    case 0:
                        tv2_len.setText("Meter");
                        String tvsec =  tv1_len.getText().toString();
                        String s = et1_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double mtr = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                dtostr = mtr.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                Double cm = mtr/100;
                                dtostr = cm.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                Double ft = mtr/3.281 ;
                                dtostr = ft.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                Double in = mtr/39.37;
                                dtostr = in.toString();
                                et2_len.setText(dtostr);
                            }

                        }
                        break;
                    case 1:
                        tv2_len.setText("Centimeter");
                        tvsec =  tv1_len.getText().toString();
                        s = et1_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double cm = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                Double mtr = cm*100;
                                dtostr = mtr.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                dtostr = cm.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                Double ft = cm*30.48;
                                dtostr = ft.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                Double in = cm*2.54;
                                dtostr = in.toString();
                                et2_len.setText(dtostr);
                            }

                        }
                        break;
                    case 2:
                        tv2_len.setText("Millimeter");
                        tvsec =  tv1_len.getText().toString();
                        s = et1_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double mm = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                Double mtr = mm*1000;
                                dtostr = mtr.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                Double cm = mm*100;
                                dtostr = cm.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                Double ft = mm*304.8;
                                dtostr = ft.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                Double in = mm*25.4;
                                dtostr = in.toString();
                                et2_len.setText(dtostr);
                            }

                        }

                        break;
                    case 3:
                        tv2_len.setText("Foot");
                        tvsec =  tv1_len.getText().toString();
                        s = et1_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double ft = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                Double mtr = ft*3.281;
                                dtostr = mtr.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                Double cm = ft/30.48;
                                dtostr = cm.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                dtostr = ft.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                Double in = ft/12;
                                dtostr = in.toString();
                                et2_len.setText(dtostr);
                            }

                        }
                        break;
                    case 4:
                        tv2_len.setText("Inch");
                        tvsec =  tv1_len.getText().toString();
                        s = et1_len.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double in = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Meter")) {
                                Double mtr = in* 39.37;
                                dtostr = mtr.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Centimeter")) {
                                Double cm = in/2.54;
                                dtostr = cm.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Foot")) {
                                Double ft = in*12;
                                dtostr = in.toString();
                                et2_len.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Inch")) {
                                dtostr = in.toString();
                                et2_len.setText(dtostr);
                            }

                        }

                        break;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter bb = new ArrayAdapter (this,android.R.layout.simple_spinner_item, length);
        bb.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin2.setAdapter(bb);



    }


}









