package com.example.unicon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class distance extends AppCompatActivity {

    String[] distance = {"Kilometer","Mile", "Yard"};
    TextView tv1_dist;
    TextView tv2_dist;
    EditText et1_dist;
    EditText et2_dist;
    String dtostr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance);
        tv1_dist = findViewById(R.id.tv1_dist);
        tv2_dist = findViewById(R.id.tv2_dist);
        et1_dist = findViewById(R.id.et1_dist);
        et2_dist = findViewById(R.id.et2_dist);

        setTitle("Convert Length");

        Spinner spin = (Spinner) findViewById(R.id.spn_dist);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                switch(i){
                    case 0:
                        tv1_dist.setText("Kilometer");
                        String tvsec =  tv2_dist.getText().toString();
                        String s = et2_dist.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double km = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilometer")) {
                                dtostr = km.toString();
                                et1_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Mile")) {
                                Double mile = km*1.609;
                                dtostr = mile.toString();
                                et1_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Yard")) {
                                Double yd = km/1094;
                                dtostr = yd.toString();
                                et1_dist.setText(dtostr);
                            }
                        }

                        break;
                    case 1:
                        tv1_dist.setText("Mile");
                        tvsec =  tv2_dist.getText().toString();
                        s = et2_dist.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double mile = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilometer")) {
                                Double km = mile/1.609;
                                dtostr = km.toString();
                                et1_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Mile")) {
                                dtostr = mile.toString();
                                et1_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Yard")) {
                                Double yd = mile/1760;
                                dtostr = yd.toString();
                                et1_dist.setText(dtostr);
                            }
                        }
                        break;
                    case 2:
                        tv1_dist.setText("Yard");
                        tvsec =  tv2_dist.getText().toString();
                        s = et2_dist.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double yd = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilometer")) {
                                Double km = yd*1094;
                                dtostr = km.toString();
                                et1_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Mile")) {
                                Double mile = yd*1760;
                                dtostr = mile.toString();
                                et1_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Yard")) {
                                dtostr = yd.toString();
                                et1_dist.setText(dtostr);
                            }
                        }
                        break;

                }



            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, distance);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(aa);


        Spinner spin2 = (Spinner) findViewById(R.id.spn_dist2);
        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {



                switch(i){
                    case 0:
                        tv2_dist.setText("Kilometer");
                        String tvsec =  tv1_dist.getText().toString();
                        String s = et1_dist.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double km = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilometer")) {
                                dtostr = km.toString();
                                et2_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Mile")) {
                                Double mile = km*1.609;
                                dtostr = mile.toString();
                                et2_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Yard")) {
                                Double yd = km/1094;
                                dtostr = yd.toString();
                                et2_dist.setText(dtostr);
                            }
                        }
                        break;
                    case 1:
                        tv2_dist.setText("Mile");
                        tvsec =  tv1_dist.getText().toString();
                        s = et1_dist.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double mile = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilometer")) {
                                Double km = mile/1.609;
                                dtostr = km.toString();
                                et2_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Mile")) {
                                dtostr = mile.toString();
                                et2_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Yard")) {
                                Double yd = mile/1760;
                                dtostr = yd.toString();
                                et2_dist.setText(dtostr);
                            }
                        }
                        break;
                    case 2:
                        tv2_dist.setText("Yard");
                        tvsec =  tv1_dist.getText().toString();
                        s = et1_dist.getText().toString();
                        if(!s.equals("") && s!=null) {
                            Double yd = Double.parseDouble(s);
                            if (tvsec.equalsIgnoreCase("Kilometer")) {
                                Double km = yd*1094;
                                dtostr = km.toString();
                                et2_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Mile")) {
                                Double mile = yd*1760;
                                dtostr = mile.toString();
                                et2_dist.setText(dtostr);
                            }
                            if (tvsec.equalsIgnoreCase("Yard")) {
                                dtostr = yd.toString();
                                et2_dist.setText(dtostr);
                            }
                        }
                        break;

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        ArrayAdapter bb = new ArrayAdapter (this,android.R.layout.simple_spinner_item, distance);
        bb.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin2.setAdapter(bb);



    }


}









