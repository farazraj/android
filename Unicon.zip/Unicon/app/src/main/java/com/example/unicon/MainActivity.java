package com.example.unicon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Take instance of Action Bar
        // using getSupportActionBar and
        // if it is not Null
        // then call hide function
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

    public void open_Weight(View v) {

        Toast.makeText(this, "Opening Weight Conversion", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, weight.class);
        startActivity(intent);}

    public void open_Currency(View v) {

        Toast.makeText(this, "Opening Currency Conversion", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, currency.class);
        startActivity(intent);}

    public void open_Length(View v) {

        Toast.makeText(this, "Opening Length Conversion", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, length.class);
        startActivity(intent);}

    public void open_Distance(View v) {

        Toast.makeText(this, "Opening Distance Conversion", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, distance.class);
        startActivity(intent);}





}

